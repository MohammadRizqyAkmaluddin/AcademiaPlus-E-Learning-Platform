void main() {
  // Cetak pesan ke layar
  print('Halo, dunia dari Dart!');

  // Penjumlahan dua angka
  int a = 10;
  int b = 5;
  int hasil = a + b;

  // Tampilkan hasil
  print('Hasil dari $a + $b = $hasil');
}
